# Ginga UI

Design System privado oficial da Ginga Software. Package **`@ginga-software/ui`**, versão inicial **0.1.0**. Componentes React compartilhados para Ginga Identity, Arena, backoffices e futuros produtos.

O produto instala componentes prontos. Estrutura, comportamento, acessibilidade, estados e variantes pertencem ao Ginga UI; a identidade visual pertence aos tokens do produto. **Não copie componentes nem execute `shadcn add` dentro dos produtos para componentes disponíveis aqui.**

## Arquitetura

A fundação é o código oficial do shadcn, preset `base-nova`, com Base UI. Esse código é incorporado e passa a ser propriedade de manutenção do Ginga UI. O consumidor conhece `@ginga-software/ui`; não instala o CLI shadcn nem seus componentes individualmente.

```text
shadcn oficial + Base UI → componentes mantidos pelo Ginga UI → produtos React/Next
```

- ESM, exports explícitos e módulos preservados para tree shaking.
- Um entrypoint de componentes; nenhum subpath por componente por enquanto.
- React e React DOM são peer dependencies; nunca incluídos no bundle da biblioteca.
- Base UI, `cn`, CVA, Lucide, input-otp, cmdk e Sonner são dependências internas instaladas pelo NPM.
- cmdk é a implementação oficial de Command e possui dependências próprias; não criamos outro command engine.
- Tailwind v4 compila o CSS na biblioteca. Não há `tailwind.config.js`, configuração v3 nem necessidade de `@source` no consumidor.
- CSS distribuído separadamente; uma importação inclui tokens, preflight do Tailwind, utilitários utilizados e animações. O preflight é global: importe uma vez no ponto de entrada, antes dos overrides do produto.
- Componentes estáticos continuam utilizáveis no servidor. Os arquivos com hooks ou comportamento de browser têm `"use client"`, preservado no build; o barrel raiz não tem essa diretiva.
- Tokens light/dark em OKLCH, sem theme manager, fontes empacotadas ou identidade definitiva inventada.

## Stack verificada

Consultada no registry NPM e na documentação oficial durante a implementação. O lockfile contém as versões exatas.

| Tecnologia | Versão adotada |
| --- | --- |
| React / React DOM | 19.3.0 |
| TypeScript | 6.0.3 |
| Tailwind CSS | 4.3.3 |
| shadcn CLI | 4.21.0 |
| Base UI | 1.8.0 |
| Storybook React + Vite | 10.6.0 |
| Vite | 8.3.0 |
| Vitest | 5.0.0 |
| Next.js (fixture) | 16.3.5 |

TypeScript 7 era a versão mais recente, mas o typescript-eslint instalado suporta versões menores que 6.1; usamos 6.0.3 sem forçar peer dependencies. Use Node **24 LTS** (`.nvmrc`) e NPM. Nenhum outro package manager é utilizado.

Fontes: [React](https://react.dev/versions), [shadcn CLI](https://ui.shadcn.com/docs/cli), [Base UI Button](https://ui.shadcn.com/docs/components/base/button), [Tailwind v4](https://tailwindcss.com/docs/installation/using-vite), [detecção de classes](https://tailwindcss.com/docs/detecting-classes-in-source-files), [Vite library mode](https://vite.dev/guide/build.html#library-mode), [Storybook React Vite](https://storybook.js.org/docs/get-started/frameworks/react-vite), [Next Server/Client Components](https://nextjs.org/docs/app/getting-started/server-and-client-components).

## Instalação e registry privado

Após a primeira publicação autorizada:

```sh
npm install @ginga-software/ui
```

O projeto consumidor precisa de React e React DOM compatíveis. Dependências internas são resolvidas pelo NPM. Publicações são feitas pelo workflow de release descrito em [`docs/RELEASING.md`](docs/RELEASING.md).

### Registry genérico

Configure o escopo na configuração local do usuário, sem gravar credenciais neste repositório:

```sh
npm config set @ginga-software:registry https://registry.exemplo.interno --location=user
npm login --scope=@ginga-software --registry=https://registry.exemplo.interno
```

### GitHub Packages

```sh
npm config set @ginga-software:registry https://npm.pkg.github.com --location=user
npm login --scope=@ginga-software --auth-type=legacy --registry=https://npm.pkg.github.com
```

Use o usuário `samuelscn` e um PAT autorizado no prompt do NPM. Leitura exige permissão de acesso ao package; publicação exige permissão de escrita. O escopo `@ginga-software` corresponde à organização GitHub `ginga-software` usada por este repository. O passo a passo completo está em [`docs/RELEASING.md`](docs/RELEASING.md).

`.npmrc`, `.env` e tokens não são versionados. Configure a visibilidade **privada** e o controle de acesso no registry escolhido. `private: false` apenas permite publicar; `publishConfig.access: restricted` solicita acesso restrito em registries que suportam essa opção. Isso não substitui as permissões do registry. Veja [GitHub Packages](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-npm-registry) e [package.json](https://docs.npmjs.com/cli/v11/configuring-npm/package-json/).

## CSS e consumo

```tsx
import "@ginga-software/ui/styles.css";
import { Button, Input, Card, CardContent } from "@ginga-software/ui";

export function Example() {
  return (
    <Card>
      <CardContent>
        <Input aria-label="Nome" />
        <Button>Continuar</Button>
      </CardContent>
    </Card>
  );
}
```

Importe o CSS **uma vez** no entrypoint, ou use `@import "@ginga-software/ui/styles.css";` no CSS do produto. Não copie o CSS e não importe fontes do repositório. O exemplo Next prova o consumo sem Tailwind instalado. Se o produto usar Tailwind v4, ele continua livre para gerar suas próprias utilities; não precisa escanear este package. Evite gerar e importar o mesmo CSS da biblioteca duas vezes.

`className` permanece disponível. Utilities que só existem no código do consumidor devem ser geradas pelo Tailwind do consumidor; alternativamente use classes CSS próprias. Os estilos internos já estão compilados.

## Tokens e temas

**Ginga Default** é uma base neutra centralizada em `src/styles/tokens.css`, não uma definição final de marca.

| Intenção | Tokens |
| --- | --- |
| Página | `--background`, `--foreground` |
| Cards e popups | `--card`, `--card-foreground`, `--popover`, `--popover-foreground` |
| Ações | `--primary`, `--primary-foreground`, `--secondary`, `--secondary-foreground` |
| Ênfase e apoio | `--accent`, `--accent-foreground`, `--muted`, `--muted-foreground` |
| Erros | `--destructive`, `--destructive-foreground` |
| Controles e foco | `--border`, `--input`, `--ring` |
| Forma | `--radius` e derivados CSS-first |
| Tipografia | `--font-sans`, `--font-mono` |
| Compatibilidade futura do catálogo | `--chart-1` … `--chart-5`, tokens `--sidebar-*` oficiais |

Não há escala pública blue-100/blue-200. Espaçamento usa a escala Tailwind; shadows usam o baseline oficial. Não foram criados tokens redundantes para esses casos.

Exemplo **Arena hipotético**, somente para demonstrar overrides; estas cores **não são a identidade da Arena**:

```tsx
import "@ginga-software/ui/styles.css";
import "./product-theme.css";
```

```css
/* product-theme.css — carregado depois dos estilos do Ginga UI */
:root {
  --primary: oklch(0.4 0.13 255);
  --primary-foreground: oklch(0.99 0 0);
  --accent: oklch(0.95 0.02 255);
  --accent-foreground: oklch(0.25 0.06 255);
  --radius: 0.75rem;
  --font-sans: "Fonte do produto", ui-sans-serif, system-ui, sans-serif;
}
.dark {
  --primary: oklch(0.8 0.09 255);
  --primary-foreground: oklch(0.16 0.02 255);
  --accent: oklch(0.25 0.04 255);
  --accent-foreground: oklch(0.98 0 0);
}
```

Aplique `.dark` ao elemento `html`. O produto decide preferência, persistência e inicialização do tema; o DS não acessa localStorage. Aplicar a classe em `html` também cobre componentes renderizados em portals. Temas limitados a um subtree exigem cuidado: os portals padrão são montados em `body` e não herdam tokens de um subtree arbitrário. O padrão suportado é um tema por documento.

Sobrescreva os pares foreground/background juntos e verifique contraste, foco e estados em ambos os temas. Storybook possui seletor Light/Dark e documentação visual em Foundation.

## Componentes disponíveis

- **Básicos:** Button, Input, Label, Textarea, Checkbox, RadioGroup, Switch, Separator, Card, Badge, Avatar.
- **Feedback:** Alert, Skeleton, Spinner, Toaster e `toast` (Sonner atual, sem Toast legado).
- **Forms:** Form nativo, Field e subcomponentes, InputGroup e subcomponentes, PasswordInput, InputOTP e subcomponentes, OTPField, Select, Combobox.
- **Interação:** Tooltip/TooltipProvider, Dialog, AlertDialog, Sheet, Sidebar (SidebarProvider, SidebarTrigger, SidebarMenu*, useSidebar), Popover, DropdownMenu, Tabs, Accordion, Collapsible, Command/CommandDialog.
- **Auth:** AuthLayout, AuthCard, AuthHeader, AuthFooter, AuthDivider, LoginForm, ForgotPasswordForm, ResetPasswordForm, SocialLoginButton (`provider="google"`).

Subcomponentes de composição também são exportados pelo barrel. Storybook inclui propósito, props via Autodocs, exemplos e notas de acessibilidade por família. Não há um Link próprio: use a composição de Button quando precisar de aparência de botão em link.

### Button e composição

```tsx
<Button variant="secondary" size="lg">Salvar</Button>
<Button disabled>Indisponível</Button>
<Button variant="link" nativeButton={false} render={<a href="/ajuda" />}>
  Ajuda
</Button>
<Dialog>
  <DialogTrigger render={<Button />}>Editar</DialogTrigger>
  <DialogContent>
    <DialogTitle>Editar perfil</DialogTitle>
    <DialogDescription>Atualize seus dados.</DialogDescription>
  </DialogContent>
</Dialog>
```

Variantes: default, secondary, outline, ghost, destructive e link. Tamanhos: default, xs, sm, lg, icon, icon-xs, icon-sm e icon-lg. A composição oficial usa `render`; não existe `asChild` nesta base. Ícones sem texto precisam de `aria-label`. Wrappers de eventos devem estar dentro do limite Client Component do consumidor.

### Forms

```tsx
<Form onSubmit={(event) => { event.preventDefault(); /* consumer handles values */ }}>
  <Field data-invalid={Boolean(error)}>
    <FieldLabel htmlFor="email">E-mail</FieldLabel>
    <Input id="email" name="email" type="email" required
      aria-invalid={Boolean(error)} aria-describedby="email-help email-error" />
    <FieldDescription id="email-help">Seu endereço de contato.</FieldDescription>
    <FieldError id="email-error">{error}</FieldError>
  </Field>
  <Button type="submit">Salvar</Button>
</Form>
```

Form apenas preserva HTML e layout. Field funciona com estado React, React Hook Form ou outro gerenciador escolhido pelo consumidor. Não há dependência pública de gerenciador de formulários. Conecte explicitamente labels, descrições e erros. PasswordInput e OTPField fazem essa conexão automaticamente.

```tsx
<PasswordInput name="password" label="Nova senha" autoComplete="new-password"
  description="Política de senha do produto" error={passwordError} />
<OTPField value={code} onChange={setCode} length={6} disabled={loading}
  error={codeError} onComplete={handleComplete} />
```

InputOTP preserva `maxLength` e a API de slots conhecida. OTPField oferece `length`, label e erro prontos. O DS não interpreta códigos como TOTP, MFA ou reset.

### Feedback e ajuda

Monte `<Toaster theme={dark ? "dark" : "light"} />` uma vez e importe `toast` do Ginga UI. O default `system` segue o sistema; um tema manual do produto deve ser passado explicitamente. Tooltip requer `<TooltipProvider>` acima dos tooltips. Conteúdo essencial não deve existir apenas em tooltip.

## Auth V1: somente UI

Esses componentes **não fazem login**: não importam Better Auth, não fazem requests, não recebem tokens, não conhecem OAuth/OIDC e não armazenam credenciais. Ginga Identity será responsável pela integração real com Better Auth. Rotas, links, recuperação e mensagens vêm do consumidor.

```tsx
"use client";
import { LoginForm } from "@ginga-software/ui";

export function ProductLogin() {
  return <LoginForm
    onSubmit={async (values) => {
      // Consumer decides authentication behavior.
      // await authService.signIn(values);
      void values;
    }}
    loading={false}
    error={undefined}
    forgotPasswordLink={<a href="/forgot-password">Esqueci minha senha</a>}
  />;
}
```

- LoginForm envia `{ email, password }`; `defaultEmail` preenche o e-mail inicial.
- ForgotPasswordForm envia `{ email }`; `success` deve preferir texto genérico, por exemplo: “Se houver uma conta com esse e-mail, você receberá as instruções.”
- ResetPasswordForm envia `{ password, confirmPassword }`; valida igualdade e foca a confirmação divergente. `passwordRequirements` é descrição; `minLength` é opcional. A política e a validação do backend pertencem ao produto.
- Todos aceitam `loading`, `disabled`, `error`, `className`, `labels` e `submissionErrorMessage`. Labels são sobrescritas parcialmente; textos padrão são pt-BR. Validação nativa segue o idioma do navegador.
- A Promise de `onSubmit` é aguardada e bloqueia campos e envio. Retorne/aguarde a operação real; iniciar uma Promise sem retorná-la exige `loading` externo. Rejeições exibem mensagem genérica configurável e desbloqueiam o formulário, sem mostrar detalhes de backend.
- SocialLoginButton recebe provider, onClick, loading, disabled, label e loadingLabel. Não inicia OAuth. O ícone Google mantém suas cores; a integração final deve respeitar as [diretrizes de marca](https://developers.google.com/identity/branding-guidelines).
- O MFA Preview do Storybook demonstra OTPField em AuthCard. Ainda não há MfaChallengeForm, QR code, secrets ou lógica de desafio.

## Next.js: servidor e cliente

Importe `@ginga-software/ui/styles.css` em `app/layout.tsx`. Não configure aliases, transpilePackages ou detecção de classes do package.

```tsx
// app/page.tsx — Server Component
import { AuthLayout, AuthCard, AuthHeader } from "@ginga-software/ui";
import { ProductLogin } from "./product-login";

export default function Page() {
  return <AuthLayout><AuthCard>
    <AuthHeader title="Entrar" description="Acesse sua conta." />
    <ProductLogin />
  </AuthCard></AuthLayout>;
}
```

Callbacks comuns devem ser definidos em um arquivo `"use client"`, como ProductLogin. O servidor pode compor AuthLayout/AuthCard/Card/Label/Alert/Skeleton e wrappers estáticos sem transformar o barrel inteiro em cliente. Alguns primitives visuais, como Badge, usam hooks da base e conservam seu limite cliente.

A fixture `examples/next` instala **o tarball**, mistura servidor/cliente e comprova estilos, overrides, Dialog e callbacks sem integração de negócio:

```sh
npm run build
npm run pack:check
npm ci --prefix examples/next
npm run install:consumer
npm run build --prefix examples/next
npm run start --prefix examples/next
```

## Desenvolvimento e Storybook

```sh
npm ci
npm run dev                 # Storybook em localhost:6006
npm run storybook           # mesmo comando
npm run build-storybook    # documentação estática em storybook-static
npm run lint
npm run typecheck
npm test
npm run test:watch
npm run build
npm run pack:check          # npm pack + validação do conteúdo
npm run check              # lint, tipos, tests, build, Storybook, pack
npx playwright install chromium
npm run test:browser        # exige build-storybook; teclado, axe e screenshots
```

Storybook organiza Foundation (Colors, Typography, Radius, Spacing), Components, Forms, Feedback, Overlay e Auth. Controls/Actions/Viewport fazem parte da versão atual; Docs, Accessibility e Themes são os addons adicionais. Stories ficam próximas aos componentes. Os formulários têm default, filled, loading, error, disabled, dark e mobile; recuperação/reset também têm success.

## Testes e acessibilidade

Vitest + Testing Library cobrem render, eventos, disabled, teclado do Button, associação de Input, Dialog/foco, senha, submissão de formulários, erro e bloqueio assíncrono. Playwright valida no Chromium navegação, Dialog/focus trap, OTP/colagem, Select/Radio/Combobox, axe em light/dark e screenshots de Auth em 390px e 1440px. Não há snapshots de DOM gigantes.

O addon de acessibilidade está configurado para tratar violações como erro. A suíte de browser também executa axe diretamente sobre stories do catálogo e conteúdo modal. Automações não substituem revisão com leitores de tela reais. Ao alterar tokens ou comportamento, revise teclado, foco visível, contraste, labels e anúncios.

## Novo componente e atualização do shadcn

1. Verifique se o shadcn oficial possui o componente.
2. Adicione **neste repository**: `npx shadcn@latest add <component>`.
3. Preserve a API útil e adapte somente quando necessário. Prefira composição em arquivo separado para patterns próprios.
4. Crie story contextual com documentação, controles e estados relevantes.
5. Teste as interações críticas e acessibilidade.
6. Exporte explicitamente em `src/index.ts` e confirme os tipos publicados.
7. Documente uso e limitações; execute `npm run check` e testes de browser.
8. Publique uma nova versão autorizada. Produtos recebem a atualização pelo NPM.

`components.json` já aponta para `src/components/ui` e CSS v4, com `rsc: true`. Novas classes em componentes entram automaticamente no CSS; stories/tests não entram no CSS distribuído. Não adicione todo o catálogo por antecipação.

**Antes de atualizar código existente:** comece com commit limpo; use `npx shadcn@latest add <component> --diff`; revise a alteração antes de `--overwrite`; depois revise o diff completo, execute testes, confira as stories visualmente e empacote novamente. O shadcn copia código e pode sobrescrever adaptações. Consulte `docs/UPSTREAM.md` para as diferenças locais. A importação de CSS auxiliar do shadcn é resolvida no build; o CLI permanece devDependency.

## Versionamento e publicação

Semantic Versioning em 0.x. Registre mudanças no CHANGELOG. Enquanto a API estabiliza, mudanças incompatíveis incrementam minor; correções compatíveis incrementam patch. Não há Changesets. O workflow publica automaticamente quando um GitHub Release é criado.

```sh
npm run check
npm run test:browser
# atualize versão e CHANGELOG em uma árvore limpa
npm version patch
npm pack --pack-destination artifacts
git push origin main --follow-tags
```

Para GitHub Packages, crie o Release com a mesma versão da tag. O workflow [`publish.yml`](.github/workflows/publish.yml) executa os gates e publica com `GITHUB_TOKEN`; não registre tokens no repository. Para o procedimento completo, consulte [`docs/RELEASING.md`](docs/RELEASING.md).

O package inclui somente `dist` (ESM, .d.ts, CSS), README, licença, notices de terceiros e metadata. Testes, stories, configs, sources, maps, `.env` e node_modules ficam fora. `pack:check` verifica os arquivos, aliases, diretivas cliente e um orçamento inicial de CSS de 25 kB gzip. Dependências de runtime permanecem externas para favorecer deduplicação e tree shaking.

A CI executa `npm ci`, lint, typecheck, tests, build, build-storybook, pack validation, browser tests e build do consumidor Next. O workflow de release repete os gates e publica no GitHub Packages somente após um Release publicado.

## Estrutura

```text
src/
  components/ui/       primitives oficiais + composições genéricas, stories e testes
  components/auth/     patterns apresentacionais, stories e testes
  lib/                 utilitários internos
  styles/tokens.css    Ginga Default light/dark
  styles/globals.css   Tailwind v4 CSS-first
  stories/             Foundation
  test/                setup Vitest
  index.ts             API pública sem use client
.storybook/            React + Vite, addons e preview
examples/next/         consumidor real do tarball
scripts/               validação e distribuição
tests/browser/        axe, teclado e revisão visual
.github/workflows/     quality gates
```

## Contribuição e roadmap

Use NPM e versione os lockfiles. Mantenha TypeScript strict, sem `any`/`@ts-ignore`. Não renderize HTML arbitrário, não adicione lógica de produto e não duplique primitives por conveniência. Evite novas dependências quando composição resolver o caso. Mudanças de comportamento precisam de teste proporcional e revisão visual. Agentes de IA devem seguir [`docs/AI_CONTRIBUTING.md`](docs/AI_CONTRIBUTING.md).

1. **Foundation:** tokens, build, Storybook, testes e publicação privada — implementado.
2. **Basic primitives:** entradas, ações, superfícies e feedback — implementado.
3. **Forms/overlays:** Field, Select, Combobox, modais, menus e OTP — implementado.
4. **Auth V1:** layouts, login, recuperação, reset, Google visual e MFA preview — implementado.
5. **Catálogo restante:** adicionar conforme demanda concreta dos produtos.
6. **Auth avançado:** VerifyEmail, SignUp, MfaChallenge/Totp/RecoveryCode, outros provedores e PasskeyButton conforme contratos reais.
7. **Security Center:** SessionCard, ConnectedAccountCard, PasskeyCard e gestão apresentacional quando houver necessidade.

Security Center completo, passkey/session managers, account linking, QR TOTP, signup complexo e GitHub login específico estão fora desta entrega.
